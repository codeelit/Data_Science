package codeelit.datascience;

public class AndroidVersion {


    private String android_image_url;



    public String getAndroid_image_url() {
        return android_image_url;
    }

    public void setAndroid_image_url(String android_image_url) {
        this.android_image_url = android_image_url;
    }
}