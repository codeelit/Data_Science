
package codeelit.datascience;

public class onlyimage {

    private int image;


    public onlyimage( int image) {

        this.image = image;

    }

    public int getImg(){
        return image;
    }

}
