package codeelit.datascience;



    public class ListitemNumpy {
        private String head;
        private  String desc;

        public ListitemNumpy(String head, String desc) {
            this.head = head;
            this.desc = desc;
        }

        public String getHead() {
            return head;
        }

        public String getDesc() {
            return desc;
        }


    }


